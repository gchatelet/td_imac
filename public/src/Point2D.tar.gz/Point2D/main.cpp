#include "Point2D.hpp"

#include <cstdlib>

int main(int argc, char** argv) {
	Point2D a, b, c;
	c = a + b;
	return EXIT_SUCCESS;
}
